const {app} = require('egg-mock/bootstrap');
describe('test/controller/manger/studentRoomGrade.test.js',()=>{
    describe('room',()=>{
        // it('删除rommid测试',async ()=>{
        //     app.httpRequest().post('/manger/room/delete').send({room_id:'wvnguv-bwqm3-zsorb7-td4yqv'}).expect(200).expect({code:1});
        // })
    })
})